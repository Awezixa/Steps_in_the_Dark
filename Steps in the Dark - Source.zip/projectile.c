#include <stdio.h>
#include <stdbool.h>
#include "projectile.h"
#include "box.h"
#include "player.h"
#include "map.h"

struct projectile WIP = {6, 10, false, 0, 15};

/*
features:

- thrown 3 tiles in direction facing/ moving towards
- star shaped radius of 3 tiles. reduce after 3 steps to 1 tile, after 3 more steps extinguish
- if its wall will stop behind/ next to the wall
- limited 1 per level
*/


//Xavier
void collectProjectile(){
   if (WIP.collected)
        WIP.collected = false;
    else {

        // 0 = left | 1 = up | 2 = right | 3 down
        if (player.position_x == WIP.position_x && player.position_y == WIP.position_y) {
               
                    WIP.direction = 1;
                    WIP.collected = true;
                    map[WIP.position_x][WIP.position_y] = 'Z';
        }        
        if (player.position_x== WIP.position_x && player.position_y == WIP.position_y) {
               
                    WIP.direction = 3;
                    WIP.collected = true;
                    map[WIP.position_x][WIP.position_y] = 'Z';
        }   
        if (player.position_y < MAP_ROWS && player.position_x == WIP.position_x && player.position_y == WIP.position_y) {
              
                WIP.direction = 0;
                WIP.collected = true;
                map[WIP.position_x][WIP.position_y] = 'Z';
        }
        if (player.position_y < MAP_ROWS && player.position_x == WIP.position_x && player.position_y  == WIP.position_y) {
                WIP.direction = 2;
                WIP.collected = true;
                map[WIP.position_x][WIP.position_y] = 'Z';
        }
    } 
}




//Xavier
void throwProjectile(){
    // 0 = left | 1 = up | 2 = right | 3 down
    if (WIP.collected == true)
    {
        printf("\n\n");
        WIPDisplay();
    }
    if (WIP.direction == 1 ) {
            WIP.position_x = player.position_x + 3;
            WIP.position_y = player.position_y;
            WIP.collected = false;
            printProjRadius();
    }else if (WIP.direction == 3 ) {
            WIP.position_x = player.position_x - 3;
            WIP.position_y = player.position_y;
            WIP.collected = false;
            printProjRadius();
    }else if (WIP.direction == 0 ) {
       
            WIP.position_x = player.position_x;
            WIP.position_y = player.position_y - 3;
            WIP.collected = false;
            printProjRadius();
    }else {
        // is 2 here. everything else failed.
            WIP.position_x = player.position_x;
            WIP.position_y = player.position_y + 3;
            WIP.collected = false;
            printProjRadius();
    }
}



void printProjRadius (){
        for (int x = 0; x < MAP_ROWS; x++)
        {
                for (int y = 0; y < MAP_COLS; y++)
                {
                if (((x == player.position_x + 1 && y == player.position_y) || (x == player.position_x -1 && y == player.position_y) || (x == player.position_x && y == player.position_y + 1) || (x == player.position_x && y == player.position_y - 1) || (x == player.position_x -2 && y == player.position_y) || (x == player.position_x +2 && y == player.position_y) || (x == player.position_x && y == player.position_y-2) || (x == player.position_x && y == player.position_y+2) || (x == player.position_x +1 && y == player.position_y+1) || (x == player.position_x -1 && y == player.position_y+1) || (x == player.position_x +1 && y == player.position_y-1) || (x == player.position_x-1 && y == player.position_y-1)) && (WIP.projectileLevel > 10)) {
                if (x == box1.position_x && y == box1.position_y) 
                     printf("📦");

                else if (map[x][y] == 'X')
                    printf("🟧");
                else if (map[x][y] == 'Z')
                    printf("🟧");
                else if (map[x][y] == 'W')
                    printf("🧱");
                else if (map[x][y] == 'T')
                    printf("🕸️ ");
                else if (map[x][y] == 'P')
                    printf("🟪");
                else if (map[x][y] == 'H')
                    printf("🔒");
                else if (map[x][y] == 'K')
                     printf("🗝️ ");
                else if (map[x][y] == 'D')
                    printf("🪜 ");
                }  
                }
                
        }
        
       
}




void WIPDisplay() {
    printf("\n");
    printf("WIP Meter: ");
    if(WIP.projectileLevel == 15){
        printf("[🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩]");
    }
    if(WIP.projectileLevel == 14){
        printf("[🟩🟩🟩🟩🟩🟩🟩🟩🟩⬛]");
    }
    if(WIP.projectileLevel == 13){
        printf("[🟩🟩🟩🟩🟩🟩🟩🟩⬛⬛]");
    }
    if(WIP.projectileLevel == 12){
        printf("[🟩🟩🟩🟩🟩🟩🟩⬛⬛⬛]");
    }
    if(WIP.projectileLevel == 11){
        printf("[🟩🟩🟩🟩🟩🟩⬛⬛⬛⬛]");
    }
    if(WIP.projectileLevel == 10){
        printf("[🟨🟨🟨🟨🟨⬛⬛⬛⬛⬛]");
    }
    if(WIP.projectileLevel == 9){
        printf("[🟨🟨🟨🟨⬛⬛⬛⬛⬛⬛]");
    }
    if(WIP.projectileLevel == 8){
        printf("[🟨🟨🟨⬛⬛⬛⬛⬛⬛⬛]");
    }
    if(WIP.projectileLevel == 7){
        printf("[🟨🟨⬛⬛⬛⬛⬛⬛⬛⬛]");
    }
    if(WIP.projectileLevel == 6){
        printf("[🟥⬛⬛⬛⬛⬛⬛⬛⬛⬛]");
    }
    if(WIP.projectileLevel < 6){
        printf("[⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛]");
    }
    
}